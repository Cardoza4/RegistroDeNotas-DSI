<?php
// Configuración de reporte de errores
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// =========================================================================
// PBI-54 (CRITERIO 2): VALIDACIÓN ESTRICTA Y DESTRUCCIÓN DE SESIÓN EN BACKEND
// =========================================================================
$tiempoLimiteInactividad = 300; // 5 minutos (300 segundos)
$action = $_GET['action'] ?? $_POST['action'] ?? 'login';

if (isset($_SESSION['usuario_id'])) {
    if (isset($_SESSION['ultimo_acceso'])) {
        $tiempoTranscurrido = time() - $_SESSION['ultimo_acceso'];
        if ($tiempoTranscurrido > $tiempoLimiteInactividad) {
            // Destrucción integral de la sesión e invalidación de cookie
            session_unset();
            session_destroy();
            if (ini_get("session.use_cookies")) {
                $params = session_get_cookie_params();
                setcookie(session_name(), '', time() - 42000,
                    $params["path"], $params["domain"],
                    $params["secure"], $params["httponly"]
                );
            }
            header('Location: index.php?action=login&timeout=1');
            exit;
        }
    }
    // Actualizar marca temporal en cada solicitud activa válida
    $_SESSION['ultimo_acceso'] = time();
}

// Carga del controlador principal
$controllerPath = __DIR__ . '/controllers/AcademicoController.php';
if (!file_exists($controllerPath)) {
    die("Error crítico: No se encontró el controlador en controllers/AcademicoController.php");
}
require_once $controllerPath;

$controller = new AcademicoController();

// =========================================================================
// PBI-54 (CRITERIO 1): MONITOREO INTERACTIVO GLOBAL EN CLIENTE (FRONTEND)
// Se registra al finalizar la carga de cualquier vista autenticada
// =========================================================================
if (isset($_SESSION['usuario_id']) && !in_array($action, ['login', 'logout', 'obtener_nie'])) {
    register_shutdown_function(function() {
        // Solo inyectar en respuestas de vistas HTML (no en redirecciones puras)
        if (!headers_sent() && http_response_code() >= 300 && http_response_code() < 400) {
            return;
        }
        ?>
        <script>
        (function() {
            const TIEMPO_LIMITE_MS = 300000; // 5 minutos (300,000 ms)
            let temporizadorInactividad;

            function expulsarPorInactividad() {
                window.location.href = 'index.php?action=logout&timeout=1';
            }

            function reiniciarTemporizador() {
                clearTimeout(temporizadorInactividad);
                temporizadorInactividad = setTimeout(expulsarPorInactividad, TIEMPO_LIMITE_MS);
            }

            // Eventos físicos que reinician el contador a cero
            const eventosActividad = ['mousemove', 'mousedown', 'keydown', 'scroll', 'touchstart', 'click'];
            eventosActividad.forEach(function(evento) {
                document.addEventListener(evento, reiniciarTemporizador, { passive: true });
            });

            // Iniciar monitoreo al cargar la vista
            reiniciarTemporizador();
        })();
        </script>
        <?php
    });
}

// Enrutador del sistema
switch ($action) {

    // --- AUTENTICACIÓN Y DASHBOARD ---
    case 'login':
        $controller->login();
        if (isset($_SESSION['usuario_id'])) {
            $_SESSION['ultimo_acceso'] = time();
        }
        break;

    case 'logout':
        $esTimeout = isset($_GET['timeout']) && $_GET['timeout'] == '1';
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_unset();
            session_destroy();
            if (ini_get("session.use_cookies")) {
                $params = session_get_cookie_params();
                setcookie(session_name(), '', time() - 42000,
                    $params["path"], $params["domain"],
                    $params["secure"], $params["httponly"]
                );
            }
        }
        if ($esTimeout) {
            header('Location: index.php?action=login&timeout=1');
        } else {
            header('Location: index.php?action=login');
        }
        exit;

    case 'dashboard':
        $controller->dashboard();
        break;

    // --- GESTIÓN DE CALIFICACIONES (PBI-12, PBI-15, PBI-39, PBI-44, PBI-47) ---
    case 'gestion_notas':
    case 'control_notas':
        $controller->gestionNotas();
        break;

    case 'guardar_nota':
        $controller->guardarNota();
        break;
        
       case 'mi_historial':
        $controller->miHistorial();
        break;

    case 'guardar_recuperacion':
        $controller->guardarRecuperacion();
        break;

    case 'anular_nota':
        $controller->anularNota();
        break;

    case 'cambiar_estado_periodo':
        $controller->cambiarEstadoPeriodo();
        break;

    case 'cuadro_honor':
        $controller->cuadroHonor();
        break;

    case 'boleta_notas':
        $controller->boletaNotas();
        break;

    // --- GESTIÓN DE PERSONAL DOCENTE (ADMINISTRADOR) ---
    case 'gestion_docentes':
        $controller->gestionDocentes();
        break;

    case 'actualizar_docente_gestion':
        $controller->actualizarDocenteGestion();
        break;

    // --- MATRÍCULA Y EXPEDIENTES ESTUDIANTILES ---
    case 'matricula':
    case 'mostrar_matricula':
        $controller->mostrarMatricula();
        break;

    case 'guardar_matricula':
        $controller->guardarMatricula();
        break;

    case 'editar_estudiante':
        $controller->editarEstudiante();
        break;

    case 'actualizar_estudiante':
        $controller->actualizarEstudiante();
        break;

    // --- DIRECTORIO DE USUARIOS ---
    case 'usuarios_lista':
    case 'directorio_usuarios':
        $controller->usuariosLista();
        break;

    case 'guardar_usuario':
        $controller->guardarUsuario();
        break;

    case 'actualizar_usuario_directorio':
        $controller->actualizarUsuarioDirectorio();
        break;

    case 'eliminar_usuario':
        $controller->eliminarUsuario();
        break;

    case 'registro':
    case 'registro_usuarios':
        $controller->registroUsuarios();
        break;

    case 'obtener_nie':
        $controller->obtenerSiguienteNie();
        break;

    // --- PBI-43: VISOR DE BITÁCORA Y AUDITORÍA EN PANEL ADMIN ---
    case 'bitacora_auditoria':
        if (!isset($_SESSION['usuario_id']) || !in_array(strtoupper($_SESSION['rol'] ?? ''), ['ADMIN', 'ADMINISTRADOR'])) {
            header('Location: index.php?action=dashboard');
            exit;
        }
        $bitacoraPath = __DIR__ . '/views/bitacora_auditoria.php';
        if (file_exists($bitacoraPath)) {
            include $bitacoraPath;
        } else {
            die("Error crítico: No se encontró la vista en views/bitacora_auditoria.php");
        }
        break;

    // --- PERFIL Y CONFIGURACIÓN PERSONAL ---
    case 'datos_personales':
    case 'perfil':
        $controller->datosPersonales();
        break;

    case 'actualizar_datos_personales':
        $controller->actualizarDatosPersonales();
        break;

    case 'actualizar_foto':
    case 'actualizar_foto_perfil':
        $controller->actualizarFotoPerfil();
        break;

    case 'actualizar_password':
        $controller->actualizarPassword();
        break;
        
        case 'ejecutar_cierre_anual':
        $controller->ejecutarCierreAnual();
        break;
        
        case 'historial_alumnos':
        $controller->historialAlumnos();
        break;
        
    case 'ver_kardex':
        $controller->verKardex();
        break;
        case 'procesar_promocion_manual':
    $controller->procesarPromocionManual();
    break;

    // --- RUTA POR DEFECTO ---
    default:
        if (isset($_SESSION['usuario_id'])) {
            header('Location: index.php?action=dashboard');
        } else {
            header('Location: index.php?action=login');
        }
        exit;
}